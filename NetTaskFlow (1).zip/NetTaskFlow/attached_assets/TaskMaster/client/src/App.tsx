import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import VisaChecker from "@/pages/visa-checker";
import PromoFinder from "@/pages/promo-finder";
import BaggageRules from "@/pages/baggage-rules";
import DelayRadar from "@/pages/delay-radar";
import FeeExplorer from "@/pages/fee-explorer";
import LayoverPlanner from "@/pages/layover-planner";
import HelpCenter from "@/pages/help-center";
import ContactUs from "@/pages/contact-us";
import PrivacyPolicy from "@/pages/privacy-policy";
import TermsOfService from "@/pages/terms-of-service";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/visa-checker" component={VisaChecker} />
      <Route path="/promo-finder" component={PromoFinder} />
      <Route path="/baggage-rules" component={BaggageRules} />
      <Route path="/delay-radar" component={DelayRadar} />
      <Route path="/fee-explorer" component={FeeExplorer} />
      <Route path="/layover-planner" component={LayoverPlanner} />
      <Route path="/help-center" component={HelpCenter} />
      <Route path="/contact-us" component={ContactUs} />
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route path="/terms-of-service" component={TermsOfService} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
