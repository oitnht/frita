import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Radar, Clock, Loader2 } from "lucide-react";

export default function DelayRadar() {
  const [flightNumber, setFlightNumber] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState<any>(null);

  const handleTrack = async () => {
    if (!flightNumber) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock status
    const statuses = [
      { status: "On Time", color: "default", icon: Clock },
      { status: "Delayed", color: "destructive", icon: Clock },
      { status: "Cancelled", color: "secondary", icon: Clock }
    ];
    
    setStatus(statuses[Math.floor(Math.random() * statuses.length)]);
    setIsLoading(false);
  };

  return (
    <Card className="tool-card transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <CardContent className="mobile-card">
        <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center mb-4">
          <Radar className="w-6 h-6 text-destructive" />
        </div>
        
        <h4 className="text-xl font-semibold text-foreground mb-2">Delay Radar</h4>
        <p className="text-muted-foreground mb-6">Track real-time flight delays and disruptions.</p>
        
        <div className="space-y-4">
          <Input
            placeholder="Flight number (e.g., AA123)"
            value={flightNumber}
            onChange={(e) => setFlightNumber(e.target.value)}
          />
          
          <Button 
            onClick={handleTrack}
            disabled={!flightNumber || isLoading}
            className="w-full bg-destructive hover:bg-destructive/90 text-destructive-foreground"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Tracking...
              </>
            ) : (
              "Track Flight"
            )}
          </Button>
          
          {status && (
            <div className="mt-4 p-3 bg-accent/5 border border-accent/20 rounded-lg animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-accent" />
                <Badge variant={status.color as any} className="text-accent">
                  {status.status}
                </Badge>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
