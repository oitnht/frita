import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Ticket, Loader2 } from "lucide-react";
import { airlines } from "@/data/airlines";
import { promoCodes } from "@/data/promo-codes";

export default function PromoFinder() {
  const [selectedAirline, setSelectedAirline] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<any[]>([]);

  const handleFindCodes = async () => {
    if (!selectedAirline) return;
    
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Get randomized promo codes (3-5 results)
    const airlinePromos = promoCodes.filter(code => code.airline === selectedAirline);
    const shuffled = [...airlinePromos].sort(() => 0.5 - Math.random());
    const resultCount = Math.min(airlinePromos.length, Math.floor(Math.random() * 3) + 3); // 3-5 results
    setResults(shuffled.slice(0, resultCount));
    setIsLoading(false);
  };

  return (
    <Card className="tool-card transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <CardContent className="mobile-card">
        <div className="flex items-center justify-between mb-4">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <Ticket className="w-6 h-6 text-primary" />
          </div>
          <Badge variant="destructive" className="bg-destructive/10 text-destructive">Hot</Badge>
        </div>
        
        <h4 className="text-xl font-semibold text-foreground mb-2">Promo Code Finder</h4>
        <p className="text-muted-foreground mb-6">Discover exclusive airline discounts and promotional codes.</p>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Airline</label>
            <Select value={selectedAirline} onValueChange={setSelectedAirline}>
              <SelectTrigger>
                <SelectValue placeholder="Select airline" />
              </SelectTrigger>
              <SelectContent>
                {airlines.map((airline) => (
                  <SelectItem key={airline.code} value={airline.code}>
                    {airline.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            onClick={handleFindCodes}
            disabled={!selectedAirline || isLoading}
            className="w-full"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Finding Codes...
              </>
            ) : (
              "Find Codes"
            )}
          </Button>
          
          {results.length > 0 && (
            <div className="space-y-3 mt-4">
              {results.map((code, index) => (
                <div 
                  key={index}
                  className="p-3 bg-primary/5 border border-primary/20 rounded-lg animate-in fade-in slide-in-from-bottom-4 duration-300"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-sm font-medium text-primary">{code.code}</span>
                    <Badge variant="secondary" className="text-xs">
                      {code.discount}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{code.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
