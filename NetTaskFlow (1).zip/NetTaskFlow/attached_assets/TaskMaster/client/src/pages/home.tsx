import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import ToolNavigation from "@/components/tool-navigation";
import FeaturesSection from "@/components/features-section";
import Footer from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-muted">
      <Header />
      <HeroSection />
      
      <section id="tools" className="py-12 sm:py-16 lg:py-24">
        <div className="max-w-7xl mx-auto mobile-spacing">
          <div className="text-center mb-12 sm:mb-16">
            <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-foreground mb-4 mobile-text-balance">
              Essential Travel Tools
            </h3>
            <p className="text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto mobile-text-balance">
              Streamline your travel planning with our comprehensive suite of tools designed for modern travelers.
            </p>
          </div>

          <ToolNavigation />
        </div>
      </section>

      <FeaturesSection />
      <Footer />
    </div>
  );
}
