# GetFlyNow - Travel Companion App

## Overview

GetFlyNow is a comprehensive travel companion web application built with React, Express, and PostgreSQL. It provides essential flight-related tools for travelers including visa requirements checking, promo code discovery, baggage rules lookup, flight delay tracking, fee comparison, and layover planning. Each tool is implemented as a dedicated page with full functionality, mobile-responsive design, and colorful branded icons.

## Recent Changes

- **January 18, 2025**: Complete website redesign and rebranding
  - Rebranded from "FlightTools" to "GetFlyNow" across all components
  - Added colorful icons and buttons for each travel tool (blue, green, purple, red, orange, teal)
  - Removed sign-in functionality and CTA section per user request
  - Created comprehensive support pages: Help Center, Contact Us, Privacy Policy, Terms of Service
  - Removed social media icons from footer
  - Added PostgreSQL database integration with DatabaseStorage implementation
  - Updated navigation and footer links to support pages

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Styling**: Tailwind CSS with shadcn/ui component library using "new-york" style
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Comprehensive Radix UI primitives with custom styling
- **Development**: Hot reloading with Vite integration and Replit-specific tooling

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ESM modules
- **Database**: PostgreSQL with Neon Database (active)
- **ORM**: Drizzle ORM with TypeScript-first approach
- **Session Management**: Database storage with PostgreSQL session store
- **API Structure**: RESTful API with `/api` prefix routing

### Data Storage
- **Database**: PostgreSQL with Neon Database integration (active connection)
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Shared schema definitions between frontend and backend
- **Migrations**: Managed through Drizzle Kit with automatic schema generation
- **Storage Interface**: DatabaseStorage implementation replacing MemStorage

## Key Components

### Core Pages
1. **Home Page** - Landing page with tool overview, hero section, and navigation
2. **Visa Checker** - Check visa requirements between 190+ countries
3. **Promo Code Finder** - Search for airline discount codes and promotional offers
4. **Baggage Rules Lookup** - Check airline baggage policies, fees, and restrictions
5. **Delay Radar** - Track real-time flight delays and disruptions
6. **Fee Explorer** - Compare airline fees and hidden charges
7. **Layover Planner** - Plan airport layover activities and services

### Shared Components
- **Layout Components**: Header with smooth scrolling navigation, Footer with social links
- **UI Components**: Complete shadcn/ui component library (buttons, cards, forms, dialogs, etc.)
- **Tool Cards**: Interactive cards with hover effects and loading states
- **Statistics Section**: User engagement metrics display with animated counters

### Design System
- **Theme**: Neutral base color with CSS variables for theming
- **Typography**: Inter font family with multiple weights
- **Animations**: Smooth hover effects, slide-in animations, and loading states
- **Responsive**: Mobile-first design with comprehensive breakpoint support

## Data Flow

### Client-Side Data Management
- **Query Client**: TanStack Query for server state caching and synchronization
- **API Requests**: Centralized API request handling with error management
- **Form Management**: React Hook Form with Zod validation (via drizzle-zod)
- **State Persistence**: Session-based storage with extensible storage interface

### Server-Side Data Flow
- **Request Processing**: Express middleware for JSON parsing and logging
- **Database Operations**: Drizzle ORM with connection pooling
- **Error Handling**: Centralized error handling with proper HTTP status codes
- **Session Management**: Configurable storage backend (memory for development)

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React 18 with TypeScript support
- **Styling**: Tailwind CSS with PostCSS processing
- **Component Library**: Radix UI primitives for accessibility
- **Icons**: Lucide React for consistent iconography
- **Date Handling**: date-fns for date manipulation
- **Carousel**: Embla Carousel for smooth sliding components

### Backend Dependencies
- **Database**: Neon Database (PostgreSQL) with connection pooling
- **Session Store**: connect-pg-simple for PostgreSQL session storage
- **Development**: tsx for TypeScript execution and hot reloading
- **Build**: esbuild for production bundling

### Development Tools
- **Bundler**: Vite with React plugin and runtime error overlay
- **Type Checking**: TypeScript with strict configuration
- **Code Quality**: ESLint integration through Vite
- **Replit Integration**: Cartographer plugin for enhanced development experience

## Deployment Strategy

### Development Environment
- **Server**: Express with Vite middleware for hot reloading
- **Database**: PostgreSQL with Drizzle migrations
- **Environment**: Node.js with ESM modules and tsx for TypeScript execution
- **Port Configuration**: Express server with dynamic port assignment

### Production Build
- **Frontend**: Vite build with optimized bundling and asset management
- **Backend**: esbuild compilation to ESM format with external package handling
- **Database**: Drizzle migrations with production connection pooling
- **Assets**: Static file serving with optimized caching headers

### Configuration Management
- **Environment Variables**: DATABASE_URL for database connection
- **Build Scripts**: Separate dev/build/start commands for different environments
- **Path Aliases**: TypeScript path mapping for clean imports
- **Module System**: Full ESM support across frontend and backend

The application follows a modern full-stack architecture with emphasis on type safety, developer experience, and production readiness. The modular design allows for easy extension of travel tools and integration with external APIs for real-time data.