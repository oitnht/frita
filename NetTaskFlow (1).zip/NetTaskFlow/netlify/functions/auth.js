// Netlify serverless function for authentication-related operations

exports.handler = async (event, context) => {
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    };

    // Handle preflight requests
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: '',
        };
    }

    try {
        const user = context.clientContext?.user;
        const method = event.httpMethod;
        
        switch (method) {
            case 'GET':
                return await handleGetUserProfile(user, headers);
            
            case 'POST':
                const action = JSON.parse(event.body).action;
                switch (action) {
                    case 'updateProfile':
                        return await handleUpdateProfile(user, JSON.parse(event.body).data, headers);
                    
                    case 'deleteAccount':
                        return await handleDeleteAccount(user, headers);
                    
                    default:
                        return {
                            statusCode: 400,
                            headers,
                            body: JSON.stringify({ error: 'Invalid action' }),
                        };
                }
            
            default:
                return {
                    statusCode: 405,
                    headers,
                    body: JSON.stringify({ error: 'Method not allowed' }),
                };
        }
    } catch (error) {
        console.error('Auth function error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: 'Internal server error' }),
        };
    }
};

async function handleGetUserProfile(user, headers) {
    if (!user) {
        return {
            statusCode: 401,
            headers,
            body: JSON.stringify({ error: 'Unauthorized' }),
        };
    }

    // Return sanitized user profile
    const profile = {
        id: user.sub,
        email: user.email,
        name: user.user_metadata?.full_name || user.email.split('@')[0],
        avatar: user.user_metadata?.avatar_url,
        createdAt: user.created_at,
        lastLogin: user.updated_at,
    };

    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            profile: profile
        }),
    };
}

async function handleUpdateProfile(user, profileData, headers) {
    if (!user) {
        return {
            statusCode: 401,
            headers,
            body: JSON.stringify({ error: 'Unauthorized' }),
        };
    }

    // Validate profile data
    const allowedFields = ['full_name', 'avatar_url'];
    const sanitizedData = {};
    
    Object.keys(profileData).forEach(key => {
        if (allowedFields.includes(key)) {
            sanitizedData[key] = profileData[key];
        }
    });

    // In a real implementation, you would update the user profile
    // using Netlify Identity admin API or your database

    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            message: 'Profile updated successfully',
            updatedData: sanitizedData
        }),
    };
}

async function handleDeleteAccount(user, headers) {
    if (!user) {
        return {
            statusCode: 401,
            headers,
            body: JSON.stringify({ error: 'Unauthorized' }),
        };
    }

    // In a real implementation, you would:
    // 1. Delete all user data
    // 2. Delete the user account from Netlify Identity
    // 3. Clean up any associated resources

    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            message: 'Account deletion initiated'
        }),
    };
}
