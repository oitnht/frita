// Netlify serverless function for task operations
// This is optional and can be used for advanced features or data synchronization

exports.handler = async (event, context) => {
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    };

    // Handle preflight requests
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
            body: '',
        };
    }

    try {
        // Get user from Netlify Identity
        const user = context.clientContext?.user;
        if (!user) {
            return {
                statusCode: 401,
                headers,
                body: JSON.stringify({ error: 'Unauthorized' }),
            };
        }

        const userId = user.sub;
        const method = event.httpMethod;
        const path = event.path;

        switch (method) {
            case 'GET':
                return await handleGetTasks(userId, headers);
            
            case 'POST':
                return await handleCreateTask(userId, JSON.parse(event.body), headers);
            
            case 'PUT':
                const taskId = extractTaskId(path);
                return await handleUpdateTask(userId, taskId, JSON.parse(event.body), headers);
            
            case 'DELETE':
                const deleteTaskId = extractTaskId(path);
                return await handleDeleteTask(userId, deleteTaskId, headers);
            
            default:
                return {
                    statusCode: 405,
                    headers,
                    body: JSON.stringify({ error: 'Method not allowed' }),
                };
        }
    } catch (error) {
        console.error('Function error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: 'Internal server error' }),
        };
    }
};

function extractTaskId(path) {
    const parts = path.split('/');
    return parts[parts.length - 1];
}

async function handleGetTasks(userId, headers) {
    // In a real implementation, you would fetch from a database
    // For this example, we'll return a success response
    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            message: 'Tasks endpoint available',
            tasks: []
        }),
    };
}

async function handleCreateTask(userId, taskData, headers) {
    // Validate task data
    if (!taskData.title) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: 'Task title is required' }),
        };
    }

    // Create task with user association
    const task = {
        id: generateId(),
        userId: userId,
        ...taskData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
    };

    // In a real implementation, you would save to a database
    return {
        statusCode: 201,
        headers,
        body: JSON.stringify({
            success: true,
            task: task
        }),
    };
}

async function handleUpdateTask(userId, taskId, updates, headers) {
    if (!taskId) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: 'Task ID is required' }),
        };
    }

    // In a real implementation, you would:
    // 1. Check if task exists and belongs to user
    // 2. Update the task in database
    // 3. Return updated task

    const updatedTask = {
        id: taskId,
        userId: userId,
        ...updates,
        updatedAt: new Date().toISOString(),
    };

    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            task: updatedTask
        }),
    };
}

async function handleDeleteTask(userId, taskId, headers) {
    if (!taskId) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: 'Task ID is required' }),
        };
    }

    // In a real implementation, you would:
    // 1. Check if task exists and belongs to user
    // 2. Delete the task from database

    return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
            success: true,
            message: 'Task deleted successfully'
        }),
    };
}

function generateId() {
    return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}
