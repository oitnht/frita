import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Luggage, Loader2 } from "lucide-react";
import { airlines } from "@/data/airlines";

export default function BaggageRules() {
  const [selectedAirline, setSelectedAirline] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleCheck = async () => {
    if (!selectedAirline) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    
    // TODO: Show baggage rules results
  };

  return (
    <Card className="tool-card transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <CardContent className="mobile-card">
        <div className="w-12 h-12 bg-secondary/50 rounded-lg flex items-center justify-center mb-4">
          <Luggage className="w-6 h-6 text-foreground" />
        </div>
        
        <h4 className="text-xl font-semibold text-foreground mb-2">Baggage Rules</h4>
        <p className="text-muted-foreground mb-6">Check airline baggage policies, fees, and restrictions.</p>
        
        <div className="space-y-4">
          <Select value={selectedAirline} onValueChange={setSelectedAirline}>
            <SelectTrigger>
              <SelectValue placeholder="Select Airline" />
            </SelectTrigger>
            <SelectContent>
              {airlines.map((airline) => (
                <SelectItem key={airline.code} value={airline.code}>
                  {airline.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Button 
            onClick={handleCheck}
            disabled={!selectedAirline || isLoading}
            className="w-full bg-foreground hover:bg-foreground/90 text-background"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Checking...
              </>
            ) : (
              "Check Rules"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
