import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calculator, Loader2 } from "lucide-react";

export default function FeeExplorer() {
  const [selectedFeeType, setSelectedFeeType] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleCompareFees = async () => {
    if (!selectedFeeType) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    
    // TODO: Show fee comparison results
  };

  const feeTypes = [
    { value: "baggage", label: "Baggage Fees" },
    { value: "seat", label: "Seat Selection" },
    { value: "change", label: "Change Fees" },
    { value: "cancellation", label: "Cancellation Fees" }
  ];

  return (
    <Card className="tool-card transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <CardContent className="mobile-card">
        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
          <Calculator className="w-6 h-6 text-primary" />
        </div>
        
        <h4 className="text-xl font-semibold text-foreground mb-2">Fee Explorer</h4>
        <p className="text-muted-foreground mb-6">Compare airline fees and hidden charges.</p>
        
        <div className="space-y-4">
          <Select value={selectedFeeType} onValueChange={setSelectedFeeType}>
            <SelectTrigger>
              <SelectValue placeholder="Select Fee Type" />
            </SelectTrigger>
            <SelectContent>
              {feeTypes.map((type) => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Button 
            onClick={handleCompareFees}
            disabled={!selectedFeeType || isLoading}
            className="w-full"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Comparing...
              </>
            ) : (
              "Compare Fees"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
