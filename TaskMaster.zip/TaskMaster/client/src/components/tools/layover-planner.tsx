import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Loader2 } from "lucide-react";

export default function LayoverPlanner() {
  const [selectedAirport, setSelectedAirport] = useState("");
  const [layoverDuration, setLayoverDuration] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handlePlanLayover = async () => {
    if (!selectedAirport || !layoverDuration) return;
    
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
    
    // TODO: Show layover planning results
  };

  const airports = [
    { code: "JFK", name: "JFK - New York" },
    { code: "LAX", name: "LAX - Los Angeles" },
    { code: "LHR", name: "LHR - London" },
    { code: "DXB", name: "DXB - Dubai" },
    { code: "SIN", name: "SIN - Singapore" }
  ];

  return (
    <Card className="tool-card transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <CardContent className="mobile-card">
        <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
          <MapPin className="w-6 h-6 text-accent" />
        </div>
        
        <h4 className="text-xl font-semibold text-foreground mb-2">Layover Planner</h4>
        <p className="text-muted-foreground mb-6">Plan activities and services during airport layovers.</p>
        
        <div className="space-y-4">
          <Select value={selectedAirport} onValueChange={setSelectedAirport}>
            <SelectTrigger>
              <SelectValue placeholder="Select Airport" />
            </SelectTrigger>
            <SelectContent>
              {airports.map((airport) => (
                <SelectItem key={airport.code} value={airport.code}>
                  {airport.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Input
            placeholder="Layover duration (hours)"
            value={layoverDuration}
            onChange={(e) => setLayoverDuration(e.target.value)}
            type="number"
            min="1"
            max="24"
          />
          
          <Button 
            onClick={handlePlanLayover}
            disabled={!selectedAirport || !layoverDuration || isLoading}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Planning...
              </>
            ) : (
              "Plan Layover"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
