import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ShieldCheck, CheckCircle, Loader2 } from "lucide-react";
import { countries } from "@/data/countries";

export default function VisaChecker() {
  const [fromCountry, setFromCountry] = useState("");
  const [toCountry, setToCountry] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleCheck = async () => {
    if (!fromCountry || !toCountry) return;
    
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock result based on countries
    const mockResults = [
      { status: "required", message: "Tourist visa required for stays up to 90 days. Apply 30 days in advance.", color: "destructive" },
      { status: "visa_free", message: "Visa-free travel for up to 30 days for tourism purposes.", color: "default" },
      { status: "visa_on_arrival", message: "Visa on arrival available for stays up to 60 days.", color: "secondary" },
      { status: "eta_required", message: "Electronic Travel Authorization (ETA) required. Apply online.", color: "default" }
    ];
    
    setResult(mockResults[Math.floor(Math.random() * mockResults.length)]);
    setIsLoading(false);
  };

  return (
    <Card className="tool-card transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <CardContent className="mobile-card">
        <div className="flex items-center justify-between mb-4">
          <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 text-accent" />
          </div>
          <Badge variant="secondary" className="bg-accent/10 text-accent">Popular</Badge>
        </div>
        
        <h4 className="text-xl font-semibold text-foreground mb-2">Visa Checker</h4>
        <p className="text-muted-foreground mb-6">Check visa requirements for 190+ countries. Know before you go.</p>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">From Country</label>
            <Select value={fromCountry} onValueChange={setFromCountry}>
              <SelectTrigger>
                <SelectValue placeholder="Select your country" />
              </SelectTrigger>
              <SelectContent>
                {countries.map((country) => (
                  <SelectItem key={country.code} value={country.code}>
                    {country.flag} {country.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">To Country</label>
            <Select value={toCountry} onValueChange={setToCountry}>
              <SelectTrigger>
                <SelectValue placeholder="Select destination" />
              </SelectTrigger>
              <SelectContent>
                {countries.map((country) => (
                  <SelectItem key={country.code} value={country.code}>
                    {country.flag} {country.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            onClick={handleCheck}
            disabled={!fromCountry || !toCountry || isLoading}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Checking...
              </>
            ) : (
              "Check Requirements"
            )}
          </Button>
          
          {result && (
            <div className="mt-4 p-4 bg-accent/5 border border-accent/20 rounded-lg animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="flex items-center space-x-2 mb-2">
                <CheckCircle className="w-4 h-4 text-accent" />
                <span className="text-sm font-medium text-accent capitalize">
                  {result.status.replace("_", " ")}
                </span>
              </div>
              <p className="text-sm text-muted-foreground">{result.message}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
